import {readFile,writeFile} from 'node:fs/promises'
import {getDate} from "./divers.js";
import uuidv4, {uuid} from "uuidv4";
import crypto from 'crypto';


/* Chemin de stockage des blocks */
const path = "./data/blockchain.json"

/**
 * Mes définitions
 * @typedef { id: string, nom: string, don: number, date: string,hash: string} Block
 * @property {string} id
 * @property {string} nom
 * @property {number} don
 * @property {string} date
 * @property {string} string
 *
 */

/**
 * Renvoie un tableau json de tous les blocks
 * @return {Promise<any>}
 */
export async function findBlocks() {
    return JSON.parse(await readFile(path, "utf-8"));
}

/**
 * Trouve un block à partir de son id
 * @param partialBlock
 * @return {Promise<Block[]>}
 */
export async function findBlock(partialBlock) {
    // A coder
}

/**
 * Trouve le dernier block de la chaine
 * @return {Promise<Block|null>}
 */
export async function findLastBlock() {
    const blocks = await findBlocks();
    return blocks.length > 0 ? blocks[blocks.length - 1] : null;
}

/**
 * Creation d'un block depuis le contenu json
 * @param contenu
 * @return {Promise<Block[]>}
 */

export async function createBlock(contenu) {
    let blocks = [];
    const block = await findBlocks();
    blocks.push(block)
    const newBlock = {
        id: uuid(),
        date: getDate(),
        nom: contenu.nom,
        don: contenu.don
    };
    const lastBlock = await findLastBlock();
    if (lastBlock) {
        const data = JSON.stringify(lastBlock);
        const hash = crypto.createHash('sha256').update(data).digest('hex');
        newBlock.hash = hash;
    }

    blocks.push(newBlock);
    await writeFile(path, JSON.stringify(blocks, null, 2));
    return newBlock;
}

